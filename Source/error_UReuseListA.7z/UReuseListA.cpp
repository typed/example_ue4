// Fill out your copyright notice in the Description page of Project Settings.

#include "UReuseListA.h"
#include "Blueprint/UserWidget.h"
#include "SReuseListA.h"
#include "Runtime/Slate/Public/Widgets/Layout/SConstraintCanvas.h"

DEFINE_LOG_CATEGORY(LogUReuseListA);

UReuseListA::UReuseListA(const FObjectInitializer& ObjectInitializer)
    : Super(ObjectInitializer)
{
    sum_time = 0;
}

void UReuseListA::SynchronizeProperties()
{
    Super::SynchronizeProperties();
}

void UReuseListA::ReleaseSlateResources(bool bReleaseChildren)
{
    Super::ReleaseSlateResources(bReleaseChildren);
    MyReuseListA.Reset();
}

TSharedRef<SWidget> UReuseListA::RebuildWidget()
{
    MyReuseListA = SNew(SReuseListA)
        .OnMyTick(BIND_UOBJECT_DELEGATE(FSReuseListAOnTick, OnMyTick));
    return MyReuseListA.ToSharedRef();
}

void UReuseListA::OnMyTick(float delta)
{
    sum_time += delta;
    if (sum_time >= 20) {
        sum_time = 0;
        UUserWidget* widget = CreateWidget<UUserWidget>(GetWorld(), ItemClass);
        if (widget) {
            MyReuseListA->CanvasPanelList->AddSlot()
                .Anchors(FAnchors(0, 0, 0, 0))
                .Offset(FMargin(0, 0, 300, 100)) [
                    widget->TakeWidget()
                ];
            SynchronizeProperties();
        }
    }
}
