// Fill out your copyright notice in the Description page of Project Settings.

/**************************************************************************
Author: levingong
Date: 2018-11-15
Description: �����б�
**************************************************************************/

#pragma once

#include "CoreMinimal.h"
#include "Runtime/UMG/Public/Components/Widget.h"
#include "UReuseListA.generated.h"

/**
 * 
 */

class UUserWidget;
class SReuseListA;

UCLASS()
class EXAMPLE_UE4_API UReuseListA : public UWidget
{
	GENERATED_BODY()
	
public:

    UReuseListA(const FObjectInitializer& ObjectInitializer);

    void OnMyTick(float delta);

protected:

    UPROPERTY(EditAnywhere, Category = Property, meta = (BlueprintBaseOnly = ""))
    UClass* ItemClass;

    //~ Begin UWidget Interface
    virtual void SynchronizeProperties() override;
    //~ End UWidget Interface

    //~ Begin UVisual Interface
    virtual void ReleaseSlateResources(bool bReleaseChildren) override;
    //~ End UVisual Interface

    //~ Begin UWidget Interface
    virtual TSharedRef<SWidget> RebuildWidget() override;
    //~ End UWidget Interface

    TSharedPtr<SReuseListA> MyReuseListA;
    
    float sum_time;

};

DECLARE_LOG_CATEGORY_EXTERN(LogUReuseListA, Verbose, All);