// Fill out your copyright notice in the Description page of Project Settings.

#include "SReuseListA.h"
#include "Runtime/Slate/Public/Widgets/Layout/SScrollBox.h"
#include "Runtime/Slate/Public/Widgets/Layout/SConstraintCanvas.h"
#include "Runtime/Slate/Public/Widgets/Layout/SBox.h"

SReuseListA::SReuseListA()
{

}

void SReuseListA::Construct(const FArguments& InArgs)
{
    OnMyTick = InArgs._OnMyTick;

    ChildSlot [
        SAssignNew(ScrollBoxList, SScrollBox)
        + SScrollBox::Slot() [
            SAssignNew(CanvasPanelBg, SConstraintCanvas)
            + SConstraintCanvas::Slot()
            .Anchors(FAnchors(0, 0, 1, 0))
            .Offset(FMargin(0, 0, 0, 100)) [
                SAssignNew(SizeBoxBg, SBox)
            ]
            + SConstraintCanvas::Slot()
            .Anchors(FAnchors(0, 0, 1, 0))
            .Offset(FMargin(0, 0, 0, 100)) [
                SAssignNew(CanvasPanelList, SConstraintCanvas)
            ]
        ]
    ];

    //TPanelChildren< SConstraintCanvas::FSlot >* pc = (TPanelChildren< SConstraintCanvas::FSlot >*)CanvasPanelBg->GetChildren();
    //SConstraintCanvas::FSlot* CanvasSlot_SizeBoxBg = &(*pc)[0];

}

void SReuseListA::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
    SCompoundWidget::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);
    OnMyTick.ExecuteIfBound(InDeltaTime);
}