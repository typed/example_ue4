// Fill out your copyright notice in the Description page of Project Settings.

/**************************************************************************
Author: levingong
Date: 2018-11-15
Description: ��άͼSlate
**************************************************************************/

#pragma once

#include "CoreMinimal.h"
#include "Runtime/SlateCore/Public/Widgets/SCompoundWidget.h"

class SScrollBox;
class SConstraintCanvas;
class SBox;

DECLARE_DELEGATE_OneParam(
    FSReuseListAOnTick,
    float);

class EXAMPLE_UE4_API SReuseListA : public SCompoundWidget
{
public:
    SLATE_BEGIN_ARGS(SReuseListA)
        : _OnMyTick()
        {}
        SLATE_EVENT(FSReuseListAOnTick, OnMyTick)
    SLATE_END_ARGS()

    SReuseListA();

    void Construct(const FArguments& InArgs);

    TSharedPtr<SScrollBox> ScrollBoxList;
    TSharedPtr<SConstraintCanvas> CanvasPanelBg;
    TSharedPtr<SBox> SizeBoxBg;
    TSharedPtr<SConstraintCanvas> CanvasPanelList;

    void AddItemWidget();

    virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;

protected:

    FSReuseListAOnTick OnMyTick;

};
